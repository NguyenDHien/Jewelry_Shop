@extends('layouts.main')
@section('body')
<br>
<br>
<h1 style="text-align: center">ERROR 404</h1>
@endsection